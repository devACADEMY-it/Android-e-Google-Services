/*
 * Android e Networking
 * Disegnare sulle Google Maps
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.googleservices;

import android.graphics.Color;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap map = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        map = googleMap;

        LatLng ROMA = new LatLng(41.890158, 12.492027);
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(ROMA, 16));

        MarkerOptions markerOptions = new MarkerOptions().title("Il Colosseo").position(ROMA);
        map.addMarker(markerOptions);

        CircleOptions circleOptions = new CircleOptions().center(ROMA).radius(250).strokeColor(Color.BLUE).strokeWidth(3).fillColor(0x4466ffcc);
        map.addCircle(circleOptions);
    }

}