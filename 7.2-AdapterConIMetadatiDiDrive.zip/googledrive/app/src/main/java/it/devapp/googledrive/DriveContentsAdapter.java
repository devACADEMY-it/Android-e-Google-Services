/*
 * Android e Networking
 * Adapter con i Metadata di Drive
 *
 * Disponibile su devACADEMY.it
 */


package it.devapp.googledrive;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.MetadataBuffer;

public class DriveContentsAdapter extends BaseAdapter{

    private MetadataBuffer dataSet;

    public void setMetadataBuffer(MetadataBuffer md){
        dataSet = md;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if (dataSet == null)
            return 0;
        return dataSet.getCount();
    }

    @Override
    public Object getItem(int position) {
        if (dataSet == null)
            return null;
        return dataSet.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout, null);

        Metadata md = (Metadata) getItem(position);

        TextView filename = (TextView) convertView.findViewById(R.id.filename);
        TextView filesize = (TextView) convertView.findViewById(R.id.filesize);

        filename.setText(md.getTitle());
        filesize.setText("Dimensione: " + md.getFileSize() + " bytes");

        return convertView;
    }
}
