/*
 * Android e Networking
 * Geocoding
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.googleapiclient;

import android.Manifest;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Geocoder;
import android.location.Location;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LocationListener, GoogleApiClient.OnConnectionFailedListener, GoogleApiClient.ConnectionCallbacks {

    private static final int REQUEST_ID = 1;
    private GoogleApiClient googleApiClient;

    private static final int REQUEST_RESOLVING = 1000;
    private TextView pos_lat;
    private TextView pos_long;
    private TextView info_oraria;
    private LocationRequest mLocationRequest;
    private SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyy HH:mm");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        googleApiClient = new GoogleApiClient.Builder(this).addApi(LocationServices.API).addConnectionCallbacks(this).addOnConnectionFailedListener(this).build();
        pos_lat = (TextView) findViewById(R.id.pos_lat);
        pos_long = (TextView) findViewById(R.id.pos_long);
        info_oraria = (TextView) findViewById(R.id.info_oraria);
    }

    @Override
    protected void onStart() {
        super.onStart();
        googleApiClient.connect();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (googleApiClient.isConnected()) {
            LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, this);
            googleApiClient.disconnect();
        }
    }

    @Override
    public void onConnected(Bundle bundle) {
        mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(10000);
        mLocationRequest.setSmallestDisplacement(5);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_ID);
        }
        else
            LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, mLocationRequest, this);

        Toast.makeText(this, "Connessi!", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_ID){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                try{
                    LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, mLocationRequest, this);
                }
                catch(SecurityException se){

                }
            }
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult result) {
        if (result.hasResolution())
            try{
                result.startResolutionForResult(this, REQUEST_RESOLVING);
            } catch (IntentSender.SendIntentException e){
                googleApiClient.connect();
            }
        else{
            //
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if (requestCode == REQUEST_RESOLVING){
            if (requestCode == RESULT_OK){
                if (!googleApiClient.isConnected() && !googleApiClient.isConnecting()){
                    googleApiClient.connect();
                }
            }
        }

    }


    @Override
    public void onLocationChanged(final Location location) {

        pos_lat.setText(Double.toString(location.getLatitude()));
        pos_long.setText(Double.toString(location.getLongitude()));
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        gregorianCalendar.setTimeInMillis(location.getTime());
        info_oraria.setText(format.format(gregorianCalendar.getTime()));

        new AsyncTask<Void, Void, List<android.location.Address>>(){
            @Override
            protected List<android.location.Address> doInBackground(Void... params) {
                Geocoder geocoder = new Geocoder(MainActivity.this);
                try {
                    return geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                } catch (IOException e) {
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<android.location.Address> addresses) {
                if (addresses != null && addresses.size() > 0)
                    Toast.makeText(MainActivity.this, addresses.get(0).getLocality(), Toast.LENGTH_LONG).show();
            }
        }.execute();

    }
}
