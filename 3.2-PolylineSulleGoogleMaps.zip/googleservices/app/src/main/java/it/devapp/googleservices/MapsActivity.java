/*
 * Android e Networking
 * Polyline sulle Google Maps
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.googleservices;

import android.graphics.Color;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap map = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        map = googleMap;

        LatLng COLOSSEO = new LatLng(41.890158, 12.492027);
        LatLng FORO_ROMANO = new LatLng(41.892307, 12.485354);
        LatLng CIRCO_MASSIMO = new LatLng(41.886057, 12.485450);
        LatLng CENTRO = new LatLng(41.889507, 12.487811);

        map.moveCamera(CameraUpdateFactory.newLatLngZoom(CENTRO, 15));
        PolylineOptions polylineOptions = new PolylineOptions().add(COLOSSEO, CIRCO_MASSIMO, FORO_ROMANO, COLOSSEO).width(5).color(Color.YELLOW);

        Polyline polyline = map.addPolyline(polylineOptions);

    }

}