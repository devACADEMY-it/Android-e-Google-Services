/*
 * Android e Networking
 * Soluzione Seconda Esercitazione: “Poligoni sulle mappe”
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.googleservices;

import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap map = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    private float distanza(LatLng a, LatLng b){
        float[] res = new float[3];
        Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, res);
        return res[0];
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {

        map = googleMap;

        LatLng camera = new LatLng(45.462573, 9.190669);
        LatLng punto1 = new LatLng(45.464394, 9.187858);
        LatLng punto2 = new LatLng(45.464650, 9.194102);
        LatLng punto3 = new LatLng(45.460933, 9.195475);
        LatLng punto4 = new LatLng(45.460165, 9.187021);

        map.moveCamera(CameraUpdateFactory.newLatLngZoom(camera, 14));

        Polygon poly = map.addPolygon(new PolygonOptions().add(punto1, punto2, punto3, punto4).strokeColor(Color.RED).fillColor(0x66ff0000));

        float perimetro = distanza(punto1, punto2) + distanza(punto2, punto3) + distanza(punto3, punto4) + distanza(punto4, punto1);
        new AlertDialog.Builder(this).setPositiveButton("Chiudi", null).setMessage("Perimetro del poligono = " + Math.round(perimetro)).show();
    }

}